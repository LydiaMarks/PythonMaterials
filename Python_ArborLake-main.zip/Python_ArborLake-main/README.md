# Introductory Python Course

Welcome to the Introductory Python course.  

Start with Module 0 to set up your environment.
Proceed through modules 1 through 3 at your own pace filling out the exercises throughout each module.
Finish section 1 by completing the first lab.  This may be faciitated in a group or it may be self study.

Continue with modules 4 through 6 at your own pace filling out the exercises throughout each each module.
Finish section 2 by completing the second lab.  This may be facilitated in a group or it may be self study.

Continue with modules 7 through 10 at your own pace filling out the exercises throughout each module.
Finish section 3 by completing the third lab.  This may be faclitated in a group or it may be self study.

## Congratulations!

Once you have completed all 10 modules and 3 Labs then you will have enough knowledge to start using other 
Python resources available to continue your software development.

## Other Resources

https://www.freecodecamp.org/news/python-programming-course/

https://realpython.com/

https://automatetheboringstuff.com/

https://docs.python.org/3/tutorial/index.html
